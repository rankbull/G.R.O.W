# G.R.O.W
Global Resources for Online Wisdom - student notes exchange &amp; marketplace
